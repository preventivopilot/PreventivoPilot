PREVENTIVI SOTTO CONTROLLO — SITO INIZIALE
===========================================

COSA C'È
- index.html: pagina di presentazione responsive
- files/demo-preventivi.xlsx: demo scaricabile
- files/presentazione-servizio.pdf: presentazione commerciale

PRIMA DI PUBBLICARE
1. Apri index.html in un browser e controlla testi e collegamenti.
2. Cerca tutte le occorrenze di INSERISCI-LA-TUA-EMAIL e sostituiscile con il tuo indirizzo reale.
3. Rivedi offerta e prezzo: 149 € è un prezzo ipotetico da validare, non una vendita garantita.
4. Aggiungi i dati identificativi dell'attività e le informative legali/privacy applicabili prima di raccogliere dati o vendere.
5. Verifica il download dei file e la visualizzazione da smartphone.

COME PROVARLO IN LOCALE
- Estrai la cartella.
- Apri index.html con il browser.
- I pulsanti di download funzionano se la cartella files resta accanto a index.html.

COME PUBBLICARLO GRATIS (ESEMPIO: GITHUB PAGES)
1. Crea un account GitHub, se non ne hai uno.
2. Crea un nuovo repository pubblico, per esempio preventivi-sotto-controllo.
3. Carica index.html e la cartella files con i due file al suo interno.
4. Nelle impostazioni del repository, cerca Pages e abilita la pubblicazione dal branch principale (root).
5. Segui l'indirizzo che GitHub Pages mostra quando il sito è pubblicato. Le etichette dell'interfaccia possono cambiare.
6. Apri il sito da smartphone e prova i link.

ALTERNATIVA
Puoi usare un servizio di hosting statico gratuito che consenta di caricare una cartella o un archivio del sito. Controlla i limiti e le condizioni aggiornate del provider prima di scegliere.

LIMITI
Questo è un sito statico: non ha backend, account, database, checkout o modulo che salva richieste. Il pulsante contatti apre l'app email dell'utente. Non è stato pubblicato online e non include un dominio personalizzato.
